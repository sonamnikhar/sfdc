import { LightningElement, track } from 'lwc';

export default class ParentComponent extends LightningElement {
    @track selectedOption = '';
    @track isInput1Visible = false;
    @track isInput2Visible = false;
    @track isInput3Visible = false;

    picklistOptions = [
        { label: 'Show Input 1', value: 'Show Input 1' },
        { label: 'Show Input 2', value: 'Show Input 2' },
        { label: 'Show Input 3', value: 'Show Input 3' },
    ];

    handleOptionChange(event) {
        this.selectedOption = event.detail.value;

        // Show/hide child components based on selected option
        this.isInput1Visible = this.selectedOption === 'Show Input 1';
        this.isInput2Visible = this.selectedOption === 'Show Input 2';
        this.isInput3Visible = this.selectedOption === 'Show Input 3';
    }
}
