import { LightningElement, api } from 'lwc';

export default class ChildComponent extends LightningElement {
    @api optionValue;
    optionValue1;
    optionValue2;
    optionValue3;


    renderedCallback(){
        console.log('option 1', this.optionValue);
        if(this.optionValue == 'Show Input 1'){
            console.log('option 1');
          this.optionValue1 = true;
          this.optionValue2 = false;
          this.optionValue3 = false;
        }

        if(this.optionValue == 'Show Input 2'){
            console.log('option 1');
          this.optionValue2 = true;
          this.optionValue1 = false;
          this.optionValue3 = false;
        }

        if(this.optionValue == 'Show Input 3'){
            console.log('option 1');
          this.optionValue3 = true;
          this.optionValue2 = false;
          this.optionValue1 = false;
        }
    }
}
